import React, { Component } from "react";

class ProductItem extends Component {
  render() {
    var {product} = this.props;

    return (
      <tr>
        <td className="col_name">
          {product.first_name} 
        </td>
          <td className="col_name">
          {product.last_name} 
        </td>
        <td className="col_name">
          {product.company_name} 
        </td>
        <td className="col_name">
          {product.city} 
        </td>
        <td className="col_name">
          {product.state} 
        </td>
        <td className="col_name">
          {product.state} 
        </td>
        <td className="col_name">
          {product.zip} 
        </td>
        <td className="col_name">
          {product.email}
        </td>
        <td className="col_name">
          {product.age}
        </td>
      </tr>
    );
  }
}

export default ProductItem;
